Figure 1:
The csv only contains the GCs that worked with our method.
The zoomed region was done with the following bounds:
ax.set_ylim(-10, 5)
ax.set_xlim(245, 260)



Figure 2:
The csvs I attached is specifically for NGC 6397, the GC I chose for this figure and for the case study in the paper.
I organized them in 3 csvs: 1) ra,dec data [figure2_radec.csv], 2) tsne/umap kinematics + chemistry latent space data
[figure2_latent_kin], and 3) tsne/umap only chemistry latent space data [figure2_latent_nokin]. I only showed the tsne 
plot for B and D but umap data is also included in each of the csvs.

For ra,dec csv: The first two columns are the RA and DEC values [deg] of each star within a box of 5*RT + 1. This was done to show
a distinction of where the search box ends, such as in figure 2 C. All indexing has been adjusted accordingly for the csv.

For the tsne/umap csvs, they only contain the 5*RT stars, not any of the 5*RT+1 stars. In the figure2_latent_nokin csv, the columns of
"grouped by DBSCAN for ..." refers to if they were part of the DBSCAN identified group of chemically similar stars that includes
the identified member stars. E.g. if there were 50 identified cluster member stars and 5 more than were chemically similar to them,
the "grouped by DBSCAN for ..." column should have 55 total stars with a "1" next to them.

For the RT, RHMRT, and 5*RT values, they can be found in the csv for figure 1.

Labels of figure 2 broken down:

A: ra,dec space. Plotted the RHMRT (halfway between half-mass and tidal radius in degrees) in filled blue, the tidal radius
in unfilled blue, and all stars within the RHMRT in magenta. The 5RT search box was also plotted to show the boundaries of 
search. Background ra,dec stars within 5*RT+1 were plotted to show the field stars.

B: tsne/umap latent space from dim reduction w/ kinematics + chem abundances. Plotted all tsneX and tsneY field stars in 
the left graph with the RHMRT stars highlighted in magenta. In the right plot, plotted the DBSCAN identified group of RHMRT 
stars in cyan, RHMRT stars in red, and rest of the field stars in black.

C: ra,dec space. Plotted the tidal radius in unfilled blue and 5*RT search box in dotted black. The field stars beyond the 5*RT
field box was plotted at a lower opacity to demonstrate that they are not included in the study.

D: tsne/umap latent space from dim reduction w/ only chem abundances. Plotted all tsneX and tsneY field stars in the left graph
with the DBSCAN identified cluster member stars (the cyan stars from the right graph of B) highlighted in magenta. The right graph
shows the same but with any DBSCAN identified stars that are not already cluster member stars (magenta stars from the left graph of D)
highlighted in cyan. [Idky I kept on changing colours when making them originally, probably best to stick to one colour for identified
cluster member stars throughout]

E: ra,dec space. Idky its so dogshit looking back. Ideally should be plot C but with the extra-tidal stars highlighted.



Figure 4:
I included both the aitoff projection coords and the ra,dec coords in case we don't go with aitoff. In aitoff, the way it was visualized
was colour coding ET stars to parent GCs and shape coding between GC centres and ET stars.